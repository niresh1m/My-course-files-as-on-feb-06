import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { Auth } from '../auth';

@Component({
  selector: 'app-login',
  imports: [FormsModule],
  template: `
    <div class="login-container">
      <div class="login-card">
        <h2>Supermarket Billing System</h2>
        <div class="form-group">
          <label>Username</label>
          <input [(ngModel)]="username" type="text" class="form-control">
        </div>
        <div class="form-group">
          <label>Password</label>
          <input [(ngModel)]="password" type="password" class="form-control">
        </div>
        <button (click)="login()" class="btn btn-primary">Login</button>
        <button (click)="newAdmin()" class="btn btn-secondary">New Admin</button>
      </div>
    </div>
  `,
  styles: [`
    .login-container { display: flex; justify-content: center; align-items: center; min-height: 100vh; }
    .login-card { width: 400px; padding: 2rem; border: 1px solid #ddd; border-radius: 8px; }
    .form-group { margin-bottom: 1rem; }
    .form-control { width: 100%; padding: 0.5rem; border: 1px solid #ccc; border-radius: 4px; }
    .btn { padding: 0.5rem 1rem; margin: 0.25rem; border: none; border-radius: 4px; cursor: pointer; }
    .btn-primary { background: #007bff; color: white; }
    .btn-secondary { background: #6c757d; color: white; }
  `]
})
export class LoginComponent {
  username = '';
  password = '';

  constructor(private auth: Auth, private router: Router) {}

  login(): void {
    if (this.auth.login(this.username, this.password)) {
      this.router.navigate(['/admin']);
    } else {
      alert('Invalid credentials!');
    }
  }

  newAdmin(): void {
    const newUser = prompt('New username:');
    if (newUser) {
      const newPass = prompt('New password:');
      if (newPass) {
        this.auth.addAdmin(newUser, newPass);
        alert('Admin created!');
      }
    }
  }
}
