import { Component } from '@angular/core';

@Component({
  selector: 'app-sales-history',
  imports: [],
  templateUrl: './sales-history.html',
  styleUrl: './sales-history.css',
})
export class SalesHistory {

}
