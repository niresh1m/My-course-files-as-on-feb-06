import { Routes } from '@angular/router';
import { LoginComponent } from './login/login';
import { AdminDashboardComponent } from './admin-dashboard/admin-dashboard';
import { StockManagementComponent } from './stock-management/stock-management';
import { Billing } from './billing/billing';
import { SalesHistory } from './sales-history/sales-history';

export const routes: Routes = [
  { path: 'login', component: LoginComponent },
  { path: 'admin', component: AdminDashboardComponent },
  { path: 'stock', component: StockManagementComponent },
  { path: 'billing', component: Billing },
  { path: 'sales', component: SalesHistory },
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  { path: '**', redirectTo: 'login' }
];
