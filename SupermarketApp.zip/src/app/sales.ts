import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { Sale, CartItem } from './product.model';

@Injectable({
  providedIn: 'root'
})
export class Sales {
  private salesSubject = new BehaviorSubject<Sale[]>([]);
  public sales$ = this.salesSubject.asObservable();

  constructor() {
    const saved = localStorage.getItem('sales');
    if (saved) {
      this.salesSubject.next(JSON.parse(saved));
    }
  }

  addSale(admin: string, items: CartItem[], total: number): void {
    const sale: Sale = {
      id: Date.now().toString(),
      timestamp: new Date().toISOString(),
      admin,
      items,
      total
    };
    const sales = [...this.salesSubject.value, sale];
    this.salesSubject.next(sales);
    localStorage.setItem('sales', JSON.stringify(sales));
  }
}
