import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { Product } from './product.model';

@Injectable({
  providedIn: 'root'
})
export class Inventory {
  private productsSubject = new BehaviorSubject<Product[]>([]);
  public products$ = this.productsSubject.asObservable();

  constructor() {
    const saved = localStorage.getItem('products');
    if (saved) {
      this.productsSubject.next(JSON.parse(saved));
    }
  }

  addProduct(product: Product): void {
    const products = [...this.productsSubject.value, product];
    this.productsSubject.next(products);
    localStorage.setItem('products', JSON.stringify(products));
  }

  updateProduct(code: string, updates: Partial<Product>): void {
    const products = this.productsSubject.value.map(p =>
      p.code === code ? { ...p, ...updates } : p
    );
    this.productsSubject.next(products);
    localStorage.setItem('products', JSON.stringify(products));
  }

  deleteProduct(code: string): void {
    const products = this.productsSubject.value.filter(p => p.code !== code);
    this.productsSubject.next(products);
    localStorage.setItem('products', JSON.stringify(products));
  }

  getProduct(code: string): Product | undefined {
    return this.productsSubject.value.find(p => p.code === code);
  }
}
