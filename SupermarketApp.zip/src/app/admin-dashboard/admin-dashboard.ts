import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { Auth } from '../auth';

@Component({
  selector: 'app-admin-dashboard',
  template: `
    <div class="dashboard">
      <header>
        <h1>Welcome, {{currentUser}}!</h1>
        <button (click)="logout()" class="btn-logout">Logout</button>
      </header>
      <div class="menu-grid">
        <div class="menu-card" (click)="goToStock()">
          <h3>Stock Management</h3>
          <p>Add/Edit products & rates</p>
        </div>
        <div class="menu-card" (click)="goToBilling()">
          <h3>Billing</h3>
          <p>Generate customer bills</p>
        </div>
        <div class="menu-card" (click)="goToSales()">
          <h3>Sales History</h3>
          <p>View all transactions</p>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .dashboard { padding: 2rem; }
    header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem; }
    .menu-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 1rem; }
    .menu-card { 
      padding: 2rem; border: 1px solid #ddd; border-radius: 8px; 
      cursor: pointer; transition: box-shadow 0.2s;
    }
    .menu-card:hover { box-shadow: 0 4px 12px rgba(0,0,0,0.1); }
    .btn-logout { background: #dc3545; color: white; padding: 0.5rem 1rem; border: none; border-radius: 4px; }
  `]
})
export class AdminDashboardComponent {
  currentUser: string | null = null;

  constructor(private auth: Auth, private router: Router) {
    this.auth.currentUser$.subscribe(user => this.currentUser = user);
  }

  logout(): void {
    this.auth.logout();
    this.router.navigate(['/login']);
  }

  goToStock(): void { this.router.navigate(['/stock']); }
  goToBilling(): void { this.router.navigate(['/billing']); }
  goToSales(): void { this.router.navigate(['/sales']); }
}