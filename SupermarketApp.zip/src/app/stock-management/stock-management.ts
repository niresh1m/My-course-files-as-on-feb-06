import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Inventory } from '../inventory';
import { Product } from '../product.model';

@Component({
  selector: 'app-stock-management',
  imports: [CommonModule, FormsModule],
  template: `
    <div class="stock-management">
      <h2>Stock Management</h2>
      
      <!-- Add Product Form -->
      <div class="add-form">
        <input [(ngModel)]="newProduct.code" placeholder="Product Code" />
        <input [(ngModel)]="newProduct.name" placeholder="Product Name" />
        <input [(ngModel)]="newProduct.price" type="number" placeholder="Price" />
        <input [(ngModel)]="newProduct.stock" type="number" placeholder="Stock Qty" />
        <button (click)="addProduct()" class="btn-primary">Add Product</button>
      </div>

      <!-- Products Table -->
      <table class="products-table">
        <thead>
          <tr>
            <th>Code</th><th>Name</th><th>Price</th><th>Stock</th><th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <tr *ngFor="let product of products">
            <td>{{product.code}}</td>
            <td>{{product.name}}</td>
            <td>Rs {{product.price}}</td>
            <td>{{product.stock}}</td>
            <td>
              <button (click)="editPrice(product)" class="btn-sm">Edit Price</button>
              <button (click)="editStock(product)" class="btn-sm">Edit Stock</button>
              <button (click)="deleteProduct(product.code)" class="btn-danger">Delete</button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  `,
  styles: [`
    .stock-management { padding: 2rem; }
    .add-form { 
      display: flex; gap: 1rem; margin-bottom: 2rem; padding: 1rem; 
      background: #f8f9fa; border-radius: 8px;
    }
    .add-form input { flex: 1; padding: 0.5rem; border: 1px solid #ddd; border-radius: 4px; }
    .products-table { width: 100%; border-collapse: collapse; }
    .products-table th, .products-table td { padding: 1rem; text-align: left; border-bottom: 1px solid #ddd; }
    .btn-sm, .btn-danger { padding: 0.25rem 0.5rem; margin: 0 0.25rem; border: none; border-radius: 4px; cursor: pointer; }
    .btn-primary { background: #007bff; color: white; padding: 0.5rem 1rem; }
    .btn-danger { background: #dc3545; color: white; }
  `]
})
export class StockManagementComponent {
  products: Product[] = [];
  newProduct: Product = { code: '', name: '', price: 0, stock: 0 };

  constructor(private inventory: Inventory) {
    this.inventory.products$.subscribe(products => this.products = products);
  }

  addProduct(): void {
    if (this.newProduct.code && this.newProduct.name) {
      this.inventory.addProduct({ ...this.newProduct });
      this.newProduct = { code: '', name: '', price: 0, stock: 0 };
    }
  }

  editPrice(product: Product): void {
    const newPrice = prompt('New Price:', product.price.toString());
    if (newPrice) {
      this.inventory.updateProduct(product.code, { price: parseFloat(newPrice) });
    }
  }

  editStock(product: Product): void {
    const newStock = prompt('New Stock:', product.stock.toString());
    if (newStock) {
      this.inventory.updateProduct(product.code, { stock: parseInt(newStock, 10) });
    }
  }

  deleteProduct(code: string): void {
    if (confirm('Delete this product?')) {
      this.inventory.deleteProduct(code);
    }
  }
}
