import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class Auth {
  private admins: Record<string, string> = { admin: 'admin123' };
  private currentUserSubject = new BehaviorSubject<string | null>(null);
  public currentUser$ = this.currentUserSubject.asObservable();

  login(username: string, password: string): boolean {
    if (this.admins[username] === password) {
      this.currentUserSubject.next(username);
      localStorage.setItem('currentUser', username);
      return true;
    }
    return false;
  }

  logout(): void {
    this.currentUserSubject.next(null);
    localStorage.removeItem('currentUser');
  }

  addAdmin(username: string, password: string): void {
    this.admins[username] = password;
    localStorage.setItem('admins', JSON.stringify(this.admins));
  }

  isLoggedIn(): boolean {
    return !!this.currentUserSubject.value;
  }
}
