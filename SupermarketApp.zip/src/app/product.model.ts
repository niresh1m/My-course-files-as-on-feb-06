export interface Product {
  code: string;
  name: string;
  price: number;
  stock: number;
}

export interface CartItem {
  code: string;
  name: string;
  price: number;
  qty: number;
  total: number;
}

export interface Sale {
  id: string;
  timestamp: string;
  admin: string;
  items: CartItem[];
  total: number;
}
