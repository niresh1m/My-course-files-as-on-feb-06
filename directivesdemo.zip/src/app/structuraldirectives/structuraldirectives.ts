import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';

@Component({
  selector: 'app-structuraldirectives',
  imports: [CommonModule],
  templateUrl: './structuraldirectives.html',
  styleUrl: './structuraldirectives.css',
})
export class Structuraldirectives {
  // --- ngif
  isLoggedIn:boolean=false;
  login(){
    this.isLoggedIn=true;
  }
  logout(){
    this.isLoggedIn=false;
  }

  // ---- ngfor
    courses:string[]=['Angular','React','Vue','Node']

  //--- Switch case Example

  role: string = 'guest';   // 👈 Declare it here

  setRole(newRole: string) {
    this.role = newRole;
  }

}
