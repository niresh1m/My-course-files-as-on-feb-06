import { Component } from '@angular/core';

@Component({
  selector: 'app-test',
  imports: [],
  templateUrl: './test.html',
  styleUrl: './test.css',
})
export class Test {

  name:string[]=["Niresh kumar M","Muthaiah k"];
  course="full stack developer";
  fees=3000.23;

}