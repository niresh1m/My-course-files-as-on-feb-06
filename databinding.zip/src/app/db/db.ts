import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-db',
  imports: [FormsModule],
  templateUrl: './db.html',
  styleUrl: './db.css',
})
export class Db {
  // Interpolation
  name = "Tamilnadu";

  // Property binding
  isDisabled=false;

  // Event binding
  enableButton(){
    this.isDisabled=true;
  }
  // Two way binding
    username='';
    showAlert(){
      alert('Hello ' + this.username)
    }
}
