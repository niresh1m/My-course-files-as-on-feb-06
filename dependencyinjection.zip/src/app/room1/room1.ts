import { Component } from '@angular/core';
import { AcService } from '../acservice';

@Component({
  selector: 'app-room1',
  standalone:true,
  imports: [],
  templateUrl: './room1.html',
  styleUrl: './room1.css',
})
export class Room1 {
  message = '';

  constructor(private acservice: AcService) {}

  onAc() 
  {
    this.message = this.acservice.turnOn();
  }

  offAc() 
  {
    this.message = this.acservice.turnOff();
  }

}
