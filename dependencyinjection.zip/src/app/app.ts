import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Room1 } from './room1/room1';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet,Room1],
  standalone: true,
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('dependencyinjection');
}
