import { TestBed } from '@angular/core/testing';

import { AcService } from './acservice';

describe('Acservice', () => {
  let service: AcService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AcService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
