package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Car {
		
		public Engine enn;
		
		@Autowired
		public void setEnne(Engine en) {
			this.enn = en;
		}

		public String drive()
		{
			return enn.start();
		}
}
