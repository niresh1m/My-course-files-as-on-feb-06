package com.example.demo;

import org.springframework.stereotype.Component;

@Component
public class Car {
	
	public Engine enn;
	
	public Car(Engine en) {
		this.enn = en;
	}
	public String drive() {
		return enn.Start();
	}
	
}
