import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Chat } from './chat';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {

  username = '';
  message = '';
  messages: any[] = [];
  users: any[] = [];
  joined = false;

  constructor(private chatService: Chat) {

    this.chatService.onMessage().subscribe(data => {
      this.messages.push(data);
    });

    this.chatService.onUsers().subscribe(data => {
      this.users = data;
    });

    this.chatService.onFull().subscribe(msg => {
      alert(msg);
    });
  }

  join() {
    if (this.username.trim()) {
      this.chatService.join(this.username);
      this.joined = true;
    }
  }

  send() {
    if (this.message.trim()) {
      this.chatService.sendMessage({
        user: this.username,
        text: this.message
      });
      this.message = '';
    }
  }
}

