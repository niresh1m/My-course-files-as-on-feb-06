import { Injectable } from '@angular/core';
import { io, Socket } from 'socket.io-client';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class Chat {

  private socket: Socket;

  constructor() {
    this.socket = io('http://localhost:3000');
  }

  join(username: string) {
    this.socket.emit('join', username);
  }

  sendMessage(message: any) {
    this.socket.emit('message', message);
  }

  onMessage(): Observable<any> {
    return new Observable(observer => {
      this.socket.on('message', data => {
        observer.next(data);
      });
    });
  }

  onUsers(): Observable<any> {
    return new Observable(observer => {
      this.socket.on('users', data => {
        observer.next(data);
      });
    });
  }

  onFull(): Observable<any> {
    return new Observable(observer => {
      this.socket.on('full', msg => {
        observer.next(msg);
      });
    });
  }
}
