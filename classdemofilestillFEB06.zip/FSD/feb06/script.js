document.addEventListener('DOMContentLoaded', () => {

    // --- Sticky Header Glass Effect ---
    const header = document.querySelector('header');
    window.addEventListener('scroll', () => {
        if (window.scrollY > 50) {
            header.style.background = 'rgba(11, 22, 42, 0.98)';
            header.style.padding = '10px 0';
            header.style.boxShadow = '0 4px 20px rgba(0,0,0,0.4)';
        } else {
            header.style.background = 'rgba(11, 22, 42, 0.9)';
            header.style.padding = '15px 0';
            header.style.boxShadow = 'none';
        }
    });

    // --- Typing Effect ---
    const textToType = "Service";
    const typeTarget = document.querySelector('.type-target');
    let charIndex = 0;

    function typeEffect() {
        if (charIndex < textToType.length) {
            typeTarget.textContent += textToType.charAt(charIndex);
            charIndex++;
            setTimeout(typeEffect, 200);
        }
    }

    // Start typing after a small delay
    if (typeTarget) {
        typeTarget.textContent = '';
        setTimeout(typeEffect, 1000);
    }

    // --- Stats Counter Animation ---
    const observers = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const counter = entry.target;
                const target = +counter.getAttribute('data-target');
                const duration = 2000; // ms
                const increment = target / (duration / 16); // 60fps

                let current = 0;
                const updateCounter = () => {
                    current += increment;
                    if (current < target) {
                        counter.innerText = Math.ceil(current).toLocaleString();
                        requestAnimationFrame(updateCounter);
                    } else {
                        counter.innerText = target.toLocaleString();
                    }
                };

                updateCounter();
                observers.unobserve(counter);
            }
        });
    }, { threshold: 0.5 });

    document.querySelectorAll('.counter').forEach(counter => {
        observers.observe(counter);
    });

    // --- Scroll Reveal for Cards ---
    const revealObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, { threshold: 0.1 });

    document.querySelectorAll('.glass-card').forEach((card, index) => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(30px)';
        card.style.transition = `all 0.5s ease ${index * 0.1}s`;
        revealObserver.observe(card);
    });

    // --- Login Modal Logic ---
    const loginModal = document.getElementById('loginModal');
    const loginBtns = document.querySelectorAll('.btn-login');
    const closeModal = document.querySelector('.close-modal');

    if (loginModal) {
        // Open Modal
        loginBtns.forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                loginModal.classList.add('active');
            });
        });

        // Close Modal
        closeModal.addEventListener('click', () => {
            loginModal.classList.remove('active');
        });

        // Close on Click Outside
        loginModal.addEventListener('click', (e) => {
            if (e.target === loginModal) {
                loginModal.classList.remove('active');
            }
        });

        // Close on Escape Key
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && loginModal.classList.contains('active')) {
                loginModal.classList.remove('active');
            }
        });
    }
});
