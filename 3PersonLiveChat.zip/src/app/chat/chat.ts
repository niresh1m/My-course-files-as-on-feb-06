import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

interface Message {
  sender: string;
  text: string;
  time: Date;
}

@Component({
  selector: 'app-chat',
  imports: [CommonModule,FormsModule],
  standalone: true,
  templateUrl: './chat.html',
  styleUrls: ['./chat.css'],
})
export class Chat {

  messages: Message[] = [];

  balajiMessage: string = '';
  damMessage: string = '';
  hariMessage: string = '';

  sendMessage(sender: string) {
    let text = '';

    if (sender === 'Balaji') {
      text = this.balajiMessage;
      this.balajiMessage = '';
    } else if (sender === 'Dam') {
      text = this.damMessage;
      this.damMessage = '';
    } else if (sender === 'Hari') {
      text = this.hariMessage;
      this.hariMessage = '';
    }

    if (text.trim()) {
      this.messages.push({
        sender,
        text,
        time: new Date()
      });
    }
  }
}
