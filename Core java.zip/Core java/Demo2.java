package feb17practice;

public class Demo2 {
	int a ;
	void m1(int a)
	{
		System.out.println("dgf"+a);
		this.a=a;
	}
	void m2()
	{
		System.out.println("tha vlue of thee c is"+a);
	}
public static void main(String[] args) {
	Demo2  ss = new Demo2();
	ss.m1(3);
	ss.m2();
}
}