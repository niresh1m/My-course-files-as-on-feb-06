package feb17practice;

class abcd{
	void m1() {
		System.out.println("method m1 for parent class");
	}
}

public class child extends abcd {
	void m1() {
		System.out.println("method m1");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		child xy = new child();
		xy.m1();
	}

}
