package feb17practice;

public class practice {
	
	public practice() {
	
		System.out.println("full stack developer practice");
	}
	
	void method1() {
		System.out.println("Method 1 is working");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		practice chromepet = new practice();
		chromepet.method1();
	}

}
