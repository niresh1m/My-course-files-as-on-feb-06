package feb17practice;

class father{
	void bp()
	{

		System.out.println("I am having BP");
	}
}

public class single extends father {
	

	
public static void main(String[] args) {
	single  cc = new single();
	cc.bp();
//	cc.sugar();
}
}
