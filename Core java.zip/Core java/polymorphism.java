package feb17practice;

abstract class Abcd
{
      void m1() {
    	  System.out.println("Super");
      }
}


public class polymorphism extends Abcd {
	void m1()
	{
		
		System.out.println("method m1");
		super.m1();
	}
	
	void m1(int a)
	{

		System.out.println("method m1   a");
	}

public static void main(String[] args) {
	polymorphism  xy = new polymorphism();
	int b=10;
    xy.m1();
    xy.m1(b);

	
}
}