package feb17practice;

public class maths {
	
	public maths() {
	System.out.println("Maths Operations");
}
	void add() {
		int a = 2, b = 3;
		int c = a + b;
		System.out.println("Addition result: " + c );
	}
	
	void sub() {
		int a = 5, b = 3;
		int c = a - b;
		System.out.println("Addition result: " + c );
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		maths rsm = new maths();
		rsm.add();
		rsm.sub();
	}

}
