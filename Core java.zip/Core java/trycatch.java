package feb18class;

public class trycatch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	try {
		System.out.println("outputpoutput outputoutput");
		System.out.println("outputpoutput outputoutput");
		System.out.println(10/0);
		System.out.println("outputpoutput outputoutput");
		System.out.println("outputpoutput outputoutput");
		System.out.println("outputpoutput outputoutput");
	}
	catch (Exception e) {
		System.out.println("outputpoutput hellohello "+e);
	}
	
	System.out.println("o hellohello");
	}

}
