package feb18class;

public class systemexit0 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
	try {
		
		int a[] = {10,20,30};
		
		System.out.println(a[0]);
		System.out.println(a[1]);
		System.out.println(a[2]);
		System.out.println(a[3]);
		System.out.println(10/0);
		
	}
	
	catch (Exception e) {
		System.exit(0);
		System.out.println("Exception hellohello "+ e);
	}
	finally {
		System.out.println("exit from all");
	}
	System.out.println("o hellohello");
	}

}