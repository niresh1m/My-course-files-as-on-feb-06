package demojava;

public class test {
	
	public test(int a, int b) {
		
		int c=a+b;

		System.out.println("full stack developer  "+ c);
		System.out.println(c);
	}
	
	void bedroom()
	{
		System.out.println("Hello world");
		System.out.println("Hello world live");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		test address = new test(4,5);
		address.bedroom();
		System.out.println("Hello world live life");

	}

}
