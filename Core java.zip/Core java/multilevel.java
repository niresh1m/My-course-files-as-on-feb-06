package feb17practice;

class GrandFather 
{
	void sugar()
	{
		System.out.println("i am having sugar");
	}
}

/*
 	class father extends GrandFather{
	void bp()
	{

		System.out.println("I am having BP");
	}
}
*/

class problem extends GrandFather{
	void bp()
	{

		System.out.println("I am having BP");
	}
}

public class multilevel extends problem {
	
	
public static void main(String[] args) {
	multilevel  cc = new multilevel();
	cc.bp();
	cc.sugar();
}
}